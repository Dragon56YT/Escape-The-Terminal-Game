ESCAPE THE TERMINAL
===================

Versión: v0.10-beta
Desarrollador: Dragon56YT
Licencia: CC BY-NC 4.0

Escape the Terminal © 2025 by Dragon56YT is licensed under Creative Commons Attribution-NonCommercial 4.0 International.
To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/


DESCRIPCIÓN
-----------
Escape the Terminal es un roguelike de un solo archivo para la terminal, 
escrito en Python. Enfréntate a múltiples tipos de enemigos, recoge power-ups 
y munición, y alcanza la salida mientras avanzas por niveles generados 
proceduralmente en este laberinto digital.

CONTROLES
---------
MOVIMIENTO:
  Flechas (↑↓←→)
  WASD
  HJKL (controles estilo vi)

DISPARO:
  WASD - 4 direcciones principales
  Q/E/Z/C - Disparo diagonal

OTROS:
  P - Pausa/Menú
  ESC - Salir del juego
  Enter - Seleccionar en menús

INSTALACIÓN Y EJECUCIÓN
-----------------------
WINDOWS:
  1. pip install windows-curses
  2. python escape_terminal.py

LINUX/MACOS:
  1. python escape_terminal.py

⚠️  El juego verificará automáticamente las dependencias al inicio
⚠️  Si faltan módulos, mostrará instrucciones de instalación específicas

REQUISITOS
----------
- Python 3.6+ (mínimo) | 3.13+ (recomendado)
- Terminal con soporte para colores y curses
- Windows: biblioteca windows-curses
- Módulos estándar: random, json, time, os, pickle, base64, glob, collections, datetime

CARACTERÍSTICAS PRINCIPALES
---------------------------
SISTEMA DE JUEGO:
  - 10 niveles progresivos con dificultad creciente
  - Generación procedural con caminos garantizados
  - Sistema de puntuación detallado
  - Tiempo de juego cronometrado
  - Vida máxima aumenta cada 2 niveles
  - Sistema de animaciones visuales para acciones del juego

ENEMIGOS:
  - Básicos (E): Movimiento estándar, 1 punto de vida
  - Tanques (T): 2 puntos de vida, más lentos pero resistentes
  - Francotiradores (S): Disparan a distancia con línea de visión (radio ajustado por nivel)

POWER-UPS:
  - Salud (+): Restaura 1 punto de vida
  - Munición (o): +3 balas
  - UltraFuego (U): Dispara través paredes (7 segundos)
  - Escudo (S): Protección única contra un golpe
  - Invencibilidad (I): Inmunidad total (6 segundos)
  - Velocidad (V): Movimiento y disparo rápidos (10 segundos)

SISTEMA DE GUARDADO:
  - 5 slots de guardado
  - Autoguardado automático
  - Menús visuales para gestión
  - Metadatos completos (nivel, puntuación, tiempo)
  - Versión de guardado 0.10

OBJETIVO DEL JUEGO
------------------
1. Encuentra la salida (>) en cada nivel
2. Derrota enemigos para ganar puntos
3. Colecciona power-ups para ventajas
4. Sobrevive hasta completar los 10 niveles
5. Consigue la máxima puntuación posible

PUNTUACIÓN
----------
Enemigo básico: 100 puntos
Tanque: 300 puntos
Francotirador: 250 puntos
Completar nivel: 1000 × nivel

SEMILLAS ESPECIALES
-------------------
SAFE: Sin enemigos, escudo inicial
GOD: 999 HP y munición infinita
SPEED: Movimiento y ataques rápidos

ARCHIVOS
--------
escape_terminal.py - Juego principal
escape_saves/ - Directorio de guardados (creado automáticamente)
debug_log.txt - Log de debug (solo si DEBUG_MODE = True)

CONSEJOS DE JUEGO
-----------------
1. Prioriza la supervivencia sobre el combate
2. Gestiona bien la munición (aparece animación cuando se agota)
3. Usa los muros como protección contra francotiradores
4. Aprovecha los power-ups estratégicamente
5. Los francotiradores tienen radio reducido en niveles bajos
6. Observa el indicador ✓/✗ en el HUD para saber cuándo puedes disparar

LICENCIA
--------
Escape the Terminal © 2025 by Dragon56YT
Licensed under Creative Commons Attribution-NonCommercial 4.0 International

✅ Puedes: Copiar, modificar y distribuir para fines no comerciales
✅ Debes: Atribuir al autor original (Dragon56YT)
❌ No puedes: Usar comercialmente sin permiso

Licencia completa: https://creativecommons.org/licenses/by-nc/4.0/

ESTADO
------
¡JUEGO EN DESARROLLO BETA - v0.10!
Puede contener errores y está sujeto a cambios.

CRÉDITOS
--------
Desarrollo original: Dragon56YT

---
¿Preparado para escapar del terminal? 🎮